$('.bxslider').bxSlider({
  mode: 'fade',
  captions: true,
  controls: false
});